import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class OportunidadeService {

  apiUrl='htpp://localhost:8080/oportunidades';

  constructor(private httpClient: HttpClient) { }

  listar() {
       return this.httpClient.get(this.apiUrl);
  }
  
}
